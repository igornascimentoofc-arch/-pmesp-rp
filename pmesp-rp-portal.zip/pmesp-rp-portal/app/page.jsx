'use client';
import {useEffect,useState} from 'react';

const codes=[
["QAP","Na escuta"],["QSL","Entendido / recebido"],["QTH","Localização"],["QRV","À disposição"],["QTI","A caminho"],["TKS","Obrigado"]
];
const vtrs=[
["M-2101","SUV","Disponível"],["M-2102","Sedan","Em patrulhamento"],["M-2103","SUV","Disponível"],["M-2104","Especial","Em manutenção"]
];

export default function Home(){
 const [page,setPage]=useState("dashboard"),[on,setOn]=useState(false),[seconds,setSeconds]=useState(0),[status,setStatus]=useState("Disponível"),[q,setQ]=useState(""),[messages,setMessages]=useState([]);
 useEffect(()=>{if(!on)return;const t=setInterval(()=>setSeconds(s=>s+1),1000);return()=>clearInterval(t)},[on]);
 const fmt=s=>`${String(Math.floor(s/3600)).padStart(2,"0")}:${String(Math.floor(s%3600/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;
 const ask=()=>{if(!q.trim())return;setMessages(m=>[...m,{u:q,a:"No modo demonstração, consulte o Manual RP e os procedimentos cadastrados pela administração. Esta IA pode ser conectada depois à sua base de conhecimento para responder somente às regras do servidor."}]);setQ("")};
 return <div className="app">
  <aside><div className="brand"><div className="shield">✦</div><div><b>PMESP RP</b><small>2º BP CHOQUE</small></div></div>
  <nav>{[["dashboard","⌂","Dashboard"],["ponto","◷","Ponto"],["efetivo","♙","Efetivo"],["vtr","▣","Viaturas"],["radio","⌁","Código Q"],["manual","▤","Manual RP"],["ia","✦","Assistente IA"]].map(x=><button className={page===x[0]?"active":""} onClick={()=>setPage(x[0])} key={x[0]}>{x[1]}<span>{x[2]}</span></button>)}</nav>
  <div className="user"><div className="avatar">IN</div><div><b>CB Igor</b><small>Operacional</small></div><i>●</i></div></aside>
  <main><header><div><span className="crumb">CENTRAL /</span><h1>{({dashboard:"Dashboard",ponto:"Controle de Ponto",efetivo:"Efetivo Operacional",vtr:"Central de Viaturas",radio:"Código Q",manual:"Manual RP",ia:"Assistente IA"})[page]}</h1></div><div className="top"><span className="live">● SISTEMA ONLINE</span><button className="bell">♢</button></div></header>
  {page==="dashboard"&&<><section className="hero"><div><span className="tag">CENTRAL OPERACIONAL</span><h2>Pronto para o serviço,<br/><em>CB Igor.</em></h2><p>Acompanhe seu turno, equipe e recursos do servidor em um só lugar.</p><button className={on?"danger":"primary"} onClick={()=>{setOn(!on);if(on)setSeconds(0)}}>{on?"■ ENCERRAR SERVIÇO":"▶ INICIAR SERVIÇO"}</button></div><div className="heroBadge"><div className="ring">✦</div><b>2º BP CHOQUE</b><small>PORTAL OPERACIONAL RP</small></div></section>
  <section className="stats"><Card icon="◷" n={on?fmt(seconds):"00:00:00"} l="TEMPO DE SERVIÇO"/><Card icon="♙" n="18" l="EM SERVIÇO"/><Card icon="▣" n="12" l="NA RUA"/><Card icon="!" n="03" l="OCORRÊNCIAS"/></section>
  <section className="grid"><div className="panel"><div className="pt"><h3>Seu status</h3><span className="green">● {status}</span></div><div className="statusBtns">{["Disponível","Patrulhamento","Ocorrência","Intervalo"].map(s=><button onClick={()=>setStatus(s)} className={status===s?"sel":""} key={s}>{s}</button>)}</div></div><div className="panel"><div className="pt"><h3>Acesso rápido</h3></div><div className="quick"><button onClick={()=>setPage("radio")}>⌁ <b>Código Q</b><small>Consultar rádio</small></button><button onClick={()=>setPage("vtr")}>▣ <b>Viaturas</b><small>Ver disponibilidade</small></button><button onClick={()=>setPage("manual")}>▤ <b>Manual RP</b><small>Regras e procedimentos</small></button></div></div></section></>}
  {page==="ponto"&&<Panel title="Controle de Ponto"><div className="bigTime">{fmt(seconds)}</div><p className="muted">{on?"Turno em andamento":"Nenhum turno ativo"}</p><button className={on?"danger":"primary"} onClick={()=>{setOn(!on);if(on)setSeconds(0)}}>{on?"ENCERRAR PONTO":"BATER PONTO"}</button><div className="notice">O histórico real deverá ser salvo no banco de dados quando o backend for conectado.</div></Panel>}
  {page==="efetivo"&&<Panel title="Efetivo em tempo real"><div className="table">{[["CB Igor","Patrulhamento","M-2102","02:31"],["SD Silva","Ocorrência","M-2105","01:42"],["3º SGT Santos","Disponível","—","03:10"],["CB Oliveira","Intervalo","—","00:18"]].map(r=><div className="row">{r.map((c,i)=><span className={i===1?"pill":""}>{c}</span>)}</div>)}</div></Panel>}
  {page==="vtr"&&<Panel title="Viaturas do servidor"><div className="cards">{vtrs.map(v=><div className="vtr"><div className="car">▣</div><div><b>{v[0]}</b><small>{v[1]}</small></div><span className={v[2]==="Disponível"?"green":"yellow"}>● {v[2]}</span><button disabled={v[2]!=="Disponível"}>ASSUMIR</button></div>)}</div></Panel>}
  {page==="radio"&&<Panel title="Código Q"><input placeholder="Pesquisar código..." value={q} onChange={e=>setQ(e.target.value)}/><div className="codegrid">{codes.filter(x=>(x[0]+x[1]).toLowerCase().includes(q.toLowerCase())).map(x=><div><b>{x[0]}</b><span>{x[1]}</span></div>)}</div></Panel>}
  {page==="manual"&&<Panel title="Manual RP"><div className="manual"><h3>Antes de entrar em patrulhamento</h3><ul><li>Confira seu uniforme e equipamentos permitidos pelo servidor.</li><li>Confirme a viatura e o parceiro da equipe.</li><li>Revise as regras de comunicação e conduta do RP.</li><li>Mantenha o status atualizado durante o turno.</li></ul><h3>Importante</h3><p>Este portal é uma ferramenta para GTA RP. O conteúdo operacional deve seguir exclusivamente as regras e documentos definidos pela administração do servidor.</p></div></Panel>}
  {page==="ia"&&<Panel title="Assistente IA"><div className="chat">{messages.length===0&&<div className="empty">🤖<b>Como posso ajudar?</b><span>Pergunte sobre regras, códigos, ponto, VTRs ou procedimentos do seu servidor.</span></div>}{messages.map(m=><div className="msg"><div className="you">{m.u}</div><div className="bot"><b>Assistente</b><p>{m.a}</p></div></div>)}</div><div className="ask"><input placeholder="Digite sua dúvida..." value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ask()}/><button onClick={ask}>ENVIAR</button></div></Panel>}
  </main>
 </div>
}
function Card(p){return <div className="stat"><i>{p.icon}</i><div><b>{p.n}</b><small>{p.l}</small></div></div>}
function Panel({title,children}){return <section className="panel full"><div className="pt"><h2>{title}</h2><span className="live">● AO VIVO</span></div>{children}</section>}
