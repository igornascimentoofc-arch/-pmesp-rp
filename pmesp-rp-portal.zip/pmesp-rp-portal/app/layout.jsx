import "./globals.css";
export const metadata={title:"Central Operacional | PMESP RP",description:"Portal operacional para servidor GTA RP"};
export default function Layout({children}){return <html lang="pt-BR"><body>{children}</body></html>}